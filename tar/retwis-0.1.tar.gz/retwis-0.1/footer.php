<div id="footer">Redis is a very simple Twitter clone written in PHP as example application of the <a href="http://code.google.com/p/redis/">Redis key-value database</a></div>
</div>
</body>
</html>
