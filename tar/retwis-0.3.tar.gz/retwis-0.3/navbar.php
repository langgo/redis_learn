<div id="navbar">
<a href="index.php">home</a>
| <a href="timeline.php">timeline</a>
<?if(isLoggedIn()) {?>
| <a href="logout.php">logout</a>
<?}?>
</div>
